
export enum ThemeSwitherPos {
    navbar,
    profile,
    none,
}

export class RegistedThemes {
    static default = 'default';
    static cosmic = 'cosmic';
}


